module.exports={
    EMAIL:'pavankumar.v3909@gmail.com',
    PASSWORD:'vbhkyeijciwnvhlq'
}